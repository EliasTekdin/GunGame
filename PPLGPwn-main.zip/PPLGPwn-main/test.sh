 #!/bin/sh
luna-send -f -n 1 luna://com.webos.notification/createToast '{"message": "<b>PPLGPwn test message</b><br/>Project by: <br/>zauceee and llbranco."}'

echo 'just a test message'
